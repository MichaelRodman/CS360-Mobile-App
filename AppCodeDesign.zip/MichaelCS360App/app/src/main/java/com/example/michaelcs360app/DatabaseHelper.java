package com.example.michaelcs360app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
 * DatabaseHelper manages all SQLite database operations for the app.
 * It handles:
 * - User account storage and validation
 * - Daily weight entries (CRUD operations)
 * - Goal weight, phone number, and SMS preference storage
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // -----------------------------
    // Users table (login system)
    // -----------------------------
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // -----------------------------
    // Weights table (daily tracking)
    // -----------------------------
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_DATE = "entry_date";
    private static final String COLUMN_WEIGHT = "weight";

    // -----------------------------
    // Goal table (single record)
    // Stores goal weight, phone number, and SMS preference
    // -----------------------------
    private static final String TABLE_GOAL = "goal";
    private static final String COLUMN_GOAL_ID = "id";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_PHONE_NUMBER = "phone_number";
    private static final String COLUMN_SMS_ENABLED = "sms_enabled";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /*
     * Creates all database tables when the app is first installed.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table for login functionality
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";

        // Create weights table for daily weight tracking
        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " TEXT, "
                + COLUMN_WEIGHT + " REAL)";

        // Create goal table (stores a single record)
        String createGoalTable = "CREATE TABLE " + TABLE_GOAL + " ("
                + COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_GOAL_WEIGHT + " REAL, "
                + COLUMN_PHONE_NUMBER + " TEXT, "
                + COLUMN_SMS_ENABLED + " INTEGER)";

        // Execute all table creation commands
        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
        db.execSQL(createGoalTable);
    }

    /*
     * Handles database upgrades by dropping existing tables and recreating them.
     * (Used when DATABASE_VERSION changes)
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Drop existing tables to reset structure
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);

        // Recreate tables
        onCreate(db);
    }

    // -----------------------------
    // USER METHODS
    // -----------------------------

    /*
     * Inserts a new user into the database.
     * Returns true if successful.
     */
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /*
     * Checks whether a username already exists.
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    /*
     * Validates login credentials against the database.
     */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE "
                        + COLUMN_USERNAME + "=? AND "
                        + COLUMN_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean isValid = cursor.getCount() > 0;
        cursor.close();

        return isValid;
    }

    // -----------------------------
    // WEIGHT METHODS (CRUD)
    // -----------------------------

    /*
     * Inserts a new daily weight entry.
     */
    public boolean insertWeight(String entryDate, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, entryDate);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    /*
     * Returns all weight entries ordered by date (most recent first).
     */
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_WEIGHTS + " ORDER BY " + COLUMN_DATE + " DESC",
                null
        );
    }

    /*
     * Deletes a weight entry by its ID.
     */
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_WEIGHTS,
                COLUMN_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    /*
     * Updates an existing weight entry.
     */
    public boolean updateWeight(int id, String entryDate, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, entryDate);
        values.put(COLUMN_WEIGHT, weight);

        int result = db.update(
                TABLE_WEIGHTS,
                values,
                COLUMN_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // -----------------------------
    // GOAL / SMS METHODS
    // -----------------------------

    /*
     * Saves goal weight, phone number, and SMS preference.
     * Only one record is stored, so the table is cleared before inserting.
     */
    public boolean saveGoalWeight(double goalWeight, String phoneNumber, boolean smsEnabled) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Clear previous goal record (only one is stored)
        db.delete(TABLE_GOAL, null, null);

        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);
        values.put(COLUMN_SMS_ENABLED, smsEnabled ? 1 : 0);

        long result = db.insert(TABLE_GOAL, null, values);
        return result != -1;
    }

    /*
     * Retrieves the saved phone number for SMS alerts.
     */
    public String getPhoneNumber() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_PHONE_NUMBER + " FROM " + TABLE_GOAL + " LIMIT 1",
                null
        );

        String phoneNumber = "";

        if (cursor != null && cursor.moveToFirst()) {
            phoneNumber = cursor.getString(0);
            cursor.close();
        }

        return phoneNumber;
    }

    /*
     * Retrieves the saved goal weight.
     * Returns -1 if no goal has been set.
     */
    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_GOAL + " LIMIT 1",
                null
        );

        double goalWeight = -1;

        if (cursor != null && cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
            cursor.close();
        }

        return goalWeight;
    }

    /*
     * Returns whether SMS notifications are enabled in the app.
     */
    public boolean isSmsEnabled() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_SMS_ENABLED + " FROM " + TABLE_GOAL + " LIMIT 1",
                null
        );

        boolean smsEnabled = false;

        if (cursor != null && cursor.moveToFirst()) {
            smsEnabled = cursor.getInt(0) == 1;
            cursor.close();
        }

        return smsEnabled;
    }
}