package com.example.michaelcs360app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * EditWeightActivity allows the user to update an existing daily weight entry.
 * It loads the selected entry's date and weight from the intent extras,
 * displays them on screen, and saves the updated weight back to the database.
 */
public class EditWeightActivity extends AppCompatActivity {

    // Displays the date associated with the selected weight entry
    private TextView textDateValue;

    // Input field for editing the saved daily weight
    private EditText editDailyWeight;

    // Buttons for saving the updated weight or cancelling the edit
    private Button buttonSaveWeight;
    private Button buttonCancelAddWeight;

    // Database helper used to update the selected weight entry
    private DatabaseHelper databaseHelper;

    // Stores the id and date of the weight entry being edited
    private int weightId;
    private String entryDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Reuse the add-weight layout for editing an existing entry
        setContentView(R.layout.activity_add_weight);

        // Connect Java variables to the views in the layout
        textDateValue = findViewById(R.id.textDateValue);
        editDailyWeight = findViewById(R.id.editDailyWeight);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonCancelAddWeight = findViewById(R.id.buttonCancelAddWeight);

        // Create the database helper so the selected entry can be updated
        databaseHelper = new DatabaseHelper(this);

        // Read the selected weight entry data passed from the dashboard
        Intent intent = getIntent();
        weightId = intent.getIntExtra("weight_id", -1);
        entryDate = intent.getStringExtra("entry_date");
        double currentWeight = intent.getDoubleExtra("current_weight", 0.0);

        // Show the existing entry values on screen
        textDateValue.setText(entryDate);
        editDailyWeight.setText(String.valueOf(currentWeight));

        // Change the button text so the user knows this screen is for updating
        buttonSaveWeight.setText("Update Daily Weight");

        // Set click listeners for updating the entry or cancelling the edit
        buttonSaveWeight.setOnClickListener(v -> updateWeight());
        buttonCancelAddWeight.setOnClickListener(v -> finish());
    }

    /*
     * Updates the selected weight entry in the database.
     * The method first checks that the weight field is not blank,
     * then saves the updated value using the original entry date and id.
     */
    private void updateWeight() {
        String weightText = editDailyWeight.getText().toString().trim();

        // Prevent updating the record with a blank weight field
        if (TextUtils.isEmpty(weightText)) {
            Toast.makeText(this, "Please enter a daily weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert the input to a number and update the selected database row
        double weightValue = Double.parseDouble(weightText);
        boolean updated = databaseHelper.updateWeight(weightId, entryDate, weightValue);

        if (updated) {
            Toast.makeText(this, "Daily weight updated.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
        }
    }
}