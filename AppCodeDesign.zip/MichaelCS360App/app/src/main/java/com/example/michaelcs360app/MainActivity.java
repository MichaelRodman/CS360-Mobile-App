package com.example.michaelcs360app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/*
 * MainActivity serves as the app's login screen.
 * It allows a user to either create a new account or log in
 * with credentials already stored in the SQLite database.
 */
public class MainActivity extends AppCompatActivity {

    // Input fields for username and password
    private EditText editUsername;
    private EditText editPassword;

    // Buttons for login and account creation
    private Button buttonLogin;
    private Button buttonCreateAccount;

    // Database helper used to access user account data
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect Java variables to the views in the layout
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create the database helper so the app can read and write user data
        databaseHelper = new DatabaseHelper(this);

        // Set click listeners for the two main actions on this screen
        buttonCreateAccount.setOnClickListener(v -> createAccount());
        buttonLogin.setOnClickListener(v -> loginUser());
    }

    /*
     * Creates a new account after checking that:
     * 1. Both fields are filled in
     * 2. The username does not already exist
     * If successful, the new user is saved in the database.
     */
    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        // Prevent blank username or password values
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter both username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prevent duplicate usernames from being created
        if (databaseHelper.userExists(username)) {
            Toast.makeText(this, "Username already exists. Try another one.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert the new account into the users table
        boolean inserted = databaseHelper.insertUser(username, password);

        if (inserted) {
            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();

            // Clear the text fields after a successful account creation
            editUsername.setText("");
            editPassword.setText("");
        } else {
            Toast.makeText(this, "Account creation failed.", Toast.LENGTH_SHORT).show();
        }
    }

    /*
     * Logs in a user by checking the entered username and password
     * against the credentials stored in the database.
     * If valid, the app opens the dashboard screen.
     */
    private void loginUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        // Prevent login attempts with blank fields
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter both username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verify the entered credentials against the database
        boolean validUser = databaseHelper.validateUser(username, password);

        if (validUser) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

            // Move to the dashboard screen after a successful login
            Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }
}