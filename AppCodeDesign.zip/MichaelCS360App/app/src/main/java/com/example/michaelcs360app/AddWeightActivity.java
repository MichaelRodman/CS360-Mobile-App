package com.example.michaelcs360app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/*
 * AddWeightActivity allows the user to enter and save a new daily weight.
 * After saving the weight to the database, the activity also checks whether
 * the saved value meets or is below the goal weight and, if allowed,
 * attempts to send an SMS alert.
 */
public class AddWeightActivity extends AppCompatActivity {

    // Displays the current date for the weight entry
    private TextView textDateValue;

    // Input field for entering the daily weight
    private EditText editDailyWeight;

    // Buttons for saving the entry or cancelling and returning to the dashboard
    private Button buttonSaveWeight;
    private Button buttonCancelAddWeight;

    // Database helper used to store weights and retrieve goal/SMS settings
    private DatabaseHelper databaseHelper;

    // Stores the current date displayed for the entry
    private String currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Connect Java variables to the views in the layout
        textDateValue = findViewById(R.id.textDateValue);
        editDailyWeight = findViewById(R.id.editDailyWeight);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonCancelAddWeight = findViewById(R.id.buttonCancelAddWeight);

        // Create the database helper so the new weight can be saved
        databaseHelper = new DatabaseHelper(this);

        // Generate and display today's date for the new entry
        currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
        textDateValue.setText(currentDate);

        // Set click listeners for saving the weight or cancelling
        buttonSaveWeight.setOnClickListener(v -> saveWeight());
        buttonCancelAddWeight.setOnClickListener(v -> finish());
    }

    /*
     * Saves the entered daily weight to the database.
     * If the save is successful, the app then checks whether the user has
     * reached the goal weight and whether an SMS alert should be sent.
     */
    private void saveWeight() {
        String weightText = editDailyWeight.getText().toString().trim();

        // Prevent saving a blank weight value
        if (TextUtils.isEmpty(weightText)) {
            Toast.makeText(this, "Please enter a daily weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert the input to a number and insert it into the weights table
        double weightValue = Double.parseDouble(weightText);
        boolean inserted = databaseHelper.insertWeight(currentDate, weightValue);

        if (inserted) {
            // After saving, check whether the new weight meets the goal
            checkGoalAndSendSms(weightValue);

            Toast.makeText(this, "Daily weight saved.", Toast.LENGTH_SHORT).show();

            // Return to the dashboard after a successful save
            Intent intent = new Intent(AddWeightActivity.this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to save daily weight.", Toast.LENGTH_SHORT).show();
        }
    }

    /*
     * Checks whether the saved weight has reached or gone below the goal weight.
     * If so, the method also checks that:
     * - SMS alerts are enabled in the app
     * - A phone number has been saved
     * - Android SMS permission has been granted
     * If all conditions are met, the app attempts to send an SMS alert.
     */
    private void checkGoalAndSendSms(double weightValue) {
        double goalWeight = databaseHelper.getGoalWeight();
        String phoneNumber = databaseHelper.getPhoneNumber();

        // Exit if no goal weight has been saved yet
        if (goalWeight == -1) {
            return;
        }

        // Only continue if the current weight meets or is below the goal
        if (weightValue <= goalWeight) {

            // Stop if the user has disabled SMS alerts in the app
            if (!databaseHelper.isSmsEnabled()) {
                Toast.makeText(this, "Goal reached, but SMS notifications are turned off.", Toast.LENGTH_LONG).show();
                return;
            }

            // Stop if no phone number has been saved for alerts
            if (TextUtils.isEmpty(phoneNumber)) {
                Toast.makeText(this, "Goal reached, but no phone number is saved for SMS alerts.", Toast.LENGTH_LONG).show();
                return;
            }

            // Only try to send SMS if the Android permission has been granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSms(phoneNumber, weightValue, goalWeight);
            } else {
                Toast.makeText(this, "Goal reached, but SMS permission is not granted.", Toast.LENGTH_LONG).show();
            }
        }
    }

    /*
     * Attempts to send an SMS message to the saved phone number
     * notifying the user that the goal weight has been reached.
     * If the device cannot send SMS, the app shows a failure message
     * instead of crashing.
     */
    private void sendGoalReachedSms(String phoneNumber, double currentWeight, double goalWeight) {
        String message = "Goal reached! Your current weight is " + currentWeight
                + " lbs, which meets or is below your goal of " + goalWeight + " lbs.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached SMS alert sent.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS could not be sent on this device.", Toast.LENGTH_LONG).show();
        }
    }
}