package com.example.michaelcs360app;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/*
 * DashboardActivity is the main screen shown after a successful login.
 * It allows the user to:
 * - View the current goal weight
 * - Open the add-weight screen
 * - Open the goal/SMS settings screen
 * - View all saved weight entries
 * - Tap an entry to edit it
 * - Long-press an entry to delete it
 */
public class DashboardActivity extends AppCompatActivity {

    // Buttons for navigation to other app features
    private Button buttonAddWeight;
    private Button buttonUpdateGoal;

    // Displays the saved weight history
    private ListView listViewWeights;

    // Displays the currently saved goal weight
    private TextView textGoalValue;

    // Database helper used to read and modify stored app data
    private DatabaseHelper databaseHelper;

    // Lists used to populate the ListView and track individual row data
    private ArrayList<String> weightList;
    private ArrayList<Integer> weightIdList;
    private ArrayList<String> weightDateList;
    private ArrayList<Double> weightValueList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Connect Java variables to the views in the layout
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonUpdateGoal = findViewById(R.id.buttonUpdateGoal);
        listViewWeights = findViewById(R.id.listViewWeights);
        textGoalValue = findViewById(R.id.textGoalValue);

        // Create the database helper so dashboard data can be loaded
        databaseHelper = new DatabaseHelper(this);

        // Open the add-weight screen when the user taps the button
        buttonAddWeight.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        // Open the goal/SMS settings screen when the user taps the button
        buttonUpdateGoal.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, GoalSmsActivity.class);
            startActivity(intent);
        });

        // Open the edit screen when a weight entry is tapped
        listViewWeights.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(DashboardActivity.this, EditWeightActivity.class);
            intent.putExtra("weight_id", weightIdList.get(position));
            intent.putExtra("entry_date", weightDateList.get(position));
            intent.putExtra("current_weight", weightValueList.get(position));
            startActivity(intent);
        });

        // Show a delete confirmation dialog when an entry is long-pressed
        listViewWeights.setOnItemLongClickListener((parent, view, position, id) -> {
            int selectedWeightId = weightIdList.get(position);
            showDeleteDialog(selectedWeightId);
            return true;
        });

        // Load the initial dashboard data
        loadWeights();
        loadGoalWeight();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh the dashboard whenever the user returns to this screen
        // so updates from other activities appear immediately
        loadWeights();
        loadGoalWeight();
    }

    /*
     * Loads all saved weight entries from the database and displays them
     * in the ListView. Separate lists are also maintained so the correct
     * entry data can be passed for edit or delete actions.
     */
    private void loadWeights() {
        weightList = new ArrayList<>();
        weightIdList = new ArrayList<>();
        weightDateList = new ArrayList<>();
        weightValueList = new ArrayList<>();

        Cursor cursor = databaseHelper.getAllWeights();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                double weight = cursor.getDouble(2);

                // Store row data for later edit and delete actions
                weightIdList.add(id);
                weightDateList.add(date);
                weightValueList.add(weight);

                // Create the display text shown in the ListView
                weightList.add("Date: " + date + "  |  Weight: " + weight + " lbs");
            } while (cursor.moveToNext());

            cursor.close();
        }

        // Bind the weight data to the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                weightList
        );

        listViewWeights.setAdapter(adapter);
    }

    /*
     * Loads the current goal weight from the database and displays it.
     * If no goal has been saved, the dashboard shows "Not set."
     */
    private void loadGoalWeight() {
        double goalWeight = databaseHelper.getGoalWeight();

        if (goalWeight == -1) {
            textGoalValue.setText("Not set");
        } else {
            textGoalValue.setText(goalWeight + " lbs");
        }
    }

    /*
     * Displays a confirmation dialog before deleting a weight entry.
     * If the user confirms, the selected entry is removed from the database
     * and the ListView is refreshed.
     */
    private void showDeleteDialog(int weightId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Entry")
                .setMessage("Do you want to delete this weight entry?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean deleted = databaseHelper.deleteWeight(weightId);

                    if (deleted) {
                        Toast.makeText(this, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
                        loadWeights();
                    } else {
                        Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}