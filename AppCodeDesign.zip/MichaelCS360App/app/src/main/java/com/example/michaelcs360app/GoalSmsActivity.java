package com.example.michaelcs360app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/*
 * GoalSmsActivity allows the user to:
 * 1. Save a goal weight
 * 2. Save a phone number for alerts
 * 3. Turn SMS notifications on or off
 * 4. Request SMS permission from the device when needed
 */
public class GoalSmsActivity extends AppCompatActivity {

    // Input fields for the user's goal weight and phone number
    private EditText editGoalWeight;
    private EditText editPhoneNumber;

    // Buttons for saving settings, changing SMS preference, and returning to the dashboard
    private Button buttonSaveGoal;
    private Button buttonAllowSms;
    private Button buttonDenySms;
    private Button buttonBackToDashboard;

    // Text views used to show the current SMS notification status
    private TextView textPermissionGranted;
    private TextView textPermissionDenied;

    // Database helper used to store and retrieve goal and SMS settings
    private DatabaseHelper databaseHelper;

    // Tracks whether SMS notifications are enabled within the app
    private boolean smsPermissionEnabled = false;

    /*
     * Requests the Android SMS permission at runtime.
     * If permission is granted, SMS notifications are enabled in the app.
     * If permission is denied, SMS notifications remain disabled.
     */
    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    smsPermissionEnabled = true;
                    updateSmsStatusDisplay();
                    Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                } else {
                    smsPermissionEnabled = false;
                    updateSmsStatusDisplay();
                    Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_sms);

        // Connect Java variables to the views in the layout
        editGoalWeight = findViewById(R.id.editGoalWeight);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        buttonDenySms = findViewById(R.id.buttonDenySms);
        buttonBackToDashboard = findViewById(R.id.buttonBackToDashboard);

        textPermissionGranted = findViewById(R.id.textPermissionGranted);
        textPermissionDenied = findViewById(R.id.textPermissionDenied);

        // Create the database helper so goal and SMS settings can be loaded and saved
        databaseHelper = new DatabaseHelper(this);

        // Load the currently saved goal weight, if one exists
        double currentGoalWeight = databaseHelper.getGoalWeight();
        if (currentGoalWeight != -1) {
            editGoalWeight.setText(String.valueOf(currentGoalWeight));
        }

        // Load the saved phone number for SMS alerts
        editPhoneNumber.setText(databaseHelper.getPhoneNumber());

        // Load the saved in-app SMS preference and update the screen
        smsPermissionEnabled = databaseHelper.isSmsEnabled();
        updateSmsStatusDisplay();

        // Set click listeners for the main actions on this screen
        buttonSaveGoal.setOnClickListener(v -> saveGoalWeight());
        buttonAllowSms.setOnClickListener(v -> requestSmsPermission());
        buttonDenySms.setOnClickListener(v -> denySmsPermissionOption());
        buttonBackToDashboard.setOnClickListener(v -> finish());
    }

    /*
     * Saves the goal weight, phone number, and current SMS preference
     * to the database. The goal weight field must not be left blank.
     */
    private void saveGoalWeight() {
        String goalText = editGoalWeight.getText().toString().trim();
        String phoneNumber = editPhoneNumber.getText().toString().trim();

        // Prevent saving if the goal weight field is blank
        if (TextUtils.isEmpty(goalText)) {
            Toast.makeText(this, "Please enter a goal weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert the goal weight to a number and save all current settings
        double goalWeight = Double.parseDouble(goalText);
        boolean saved = databaseHelper.saveGoalWeight(goalWeight, phoneNumber, smsPermissionEnabled);

        if (saved) {
            Toast.makeText(this, "Goal weight and SMS preference saved.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to save goal weight.", Toast.LENGTH_SHORT).show();
        }
    }

    /*
     * Enables SMS notifications.
     * If Android permission has already been granted, the app enables SMS immediately.
     * Otherwise, it launches the runtime permission request.
     */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            smsPermissionEnabled = true;
            updateSmsStatusDisplay();
            Toast.makeText(this, "SMS notifications enabled.", Toast.LENGTH_SHORT).show();
        } else {
            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    /*
     * Disables SMS notifications within the app.
     * This does not remove Android permission, but it does stop the app
     * from treating SMS alerts as enabled.
     */
    private void denySmsPermissionOption() {
        smsPermissionEnabled = false;
        updateSmsStatusDisplay();
        Toast.makeText(this, "SMS notifications disabled.", Toast.LENGTH_SHORT).show();
    }

    /*
     * Updates the visible status message so the user can clearly see
     * whether SMS notifications are currently enabled or disabled.
     */
    private void updateSmsStatusDisplay() {
        if (smsPermissionEnabled) {
            textPermissionGranted.setVisibility(View.VISIBLE);
            textPermissionDenied.setVisibility(View.GONE);
        } else {
            textPermissionGranted.setVisibility(View.GONE);
            textPermissionDenied.setVisibility(View.VISIBLE);
        }
    }
}